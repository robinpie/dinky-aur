package dialog

import (
	"github.com/rivo/tview"
)

// CreateButtonsRow creates and configures the buttons for the message dialog
func CreateButtonsRow(buttonsFlex *tview.Flex, buttons []string, onButtonClick func(button string, index int)) []*tview.Button {
	buttonsFlex.Clear()
	tviewButtons := make([]*tview.Button, len(buttons))

	if len(buttons) == 1 {
		// If it is just one button, then center it.
		btn := tview.NewButton(buttons[0])
		tviewButtons[0] = btn
		btn.SetSelectedFunc(func() {
			if onButtonClick != nil {
				onButtonClick(buttons[0], 0)
			}
		})
		buttonsFlex.AddItem(nil, 0, 1, false)
		buttonsFlex.AddItem(btn, 0, 2, true)
		buttonsFlex.AddItem(nil, 0, 1, false)
	} else {
		for i, button := range buttons {
			btn := tview.NewButton(button)
			tviewButtons[i] = btn
			btn.SetSelectedFunc(func() {
				if onButtonClick != nil {
					onButtonClick(button, i)
				}
			})

			buttonsFlex.AddItem(btn, 0, 2, i == 0)
			if i < len(buttons)-1 {
				buttonsFlex.AddItem(nil, 0, 1, false)
			}
		}
	}

	return tviewButtons
}
